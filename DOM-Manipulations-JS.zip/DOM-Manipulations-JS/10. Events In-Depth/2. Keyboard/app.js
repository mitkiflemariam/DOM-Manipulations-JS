// https://www.w3schools.com/jsref/obj_keyboardevent.asp
const input = document.querySelector("input");
